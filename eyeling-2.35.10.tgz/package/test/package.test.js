#!/usr/bin/env node
'use strict';

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const cp = require('node:child_process');

const { C, detail, failResult, info, pass } = require('./report');

function isWin() {
  return process.platform === 'win32';
}
function npmCmd() {
  return isWin() ? 'npm.cmd' : 'npm';
}

function rmrf(p) {
  try {
    fs.rmSync(p, { recursive: true, force: true });
  } catch {}
}

function run(cmd, args, opts = {}) {
  const res = cp.spawnSync(cmd, args, {
    encoding: 'utf8',
    maxBuffer: 200 * 1024 * 1024,
    ...opts,
  });
  return res;
}

function runChecked(cmd, args, opts = {}) {
  // Print the command in a dim style
  console.log(`${C.dim}$ ${cmd} ${args.join(' ')}${C.n}`);
  const res = run(cmd, args, opts);
  if (res.error) throw res.error;
  if (res.status !== 0) {
    const err = new Error(`Command failed (${cmd} ${args.join(' ')}), exit ${res.status}`);
    err.code = res.status;
    err.stdout = res.stdout;
    err.stderr = res.stderr;
    throw err;
  }
  return res;
}

function normalizeNewlines(text) {
  return String(text).replace(/\r\n/g, '\n').replace(/\r/g, '\n');
}

function stripTrailingWhitespace(text) {
  return normalizeNewlines(text)
    .split('\n')
    .map((line) => line.replace(/[\t ]+$/g, ''))
    .join('\n');
}

function normalizeTextForCompare(text) {
  return stripTrailingWhitespace(text).trim();
}

function normalizeMarkdownForCompare(text) {
  return normalizeNewlines(text).replace(/^\n+|\n+$/g, '');
}

// Expectation logic (shared with test/examples.test.js):
// 1) If file contains:  # expect-exit: N  -> use N
// 2) Else, if it contains "=> false" -> expect exit 65
// 3) Else -> expect exit 0
function expectedExitCode(n3Text) {
  const m = n3Text.match(/^[ \t]*#[: ]*expect-exit:[ \t]*([0-9]+)\b/m);
  if (m) return parseInt(m[1], 10);
  if (/=>\s*false\b/.test(n3Text)) return 65;
  return 0;
}

function resolveExampleTrigInput(examplesDir, inputFile) {
  const stem = path.basename(inputFile, path.extname(inputFile));
  const rel = path.join('input', `${stem}.trig`);
  const abs = path.join(examplesDir, rel);
  if (!fs.existsSync(abs)) return null;
  return { abs, rel };
}

function resolveExpectedPath(outputDir, inputFile) {
  const stem = path.basename(inputFile, path.extname(inputFile));
  const preference = new Map([
    ['.md', 0],
    ['.txt', 1],
    ['.n3', 2],
  ]);
  const candidates = fs
    .readdirSync(outputDir)
    .filter((name) => path.basename(name, path.extname(name)) === stem)
    .sort((a, b) => {
      const pa = preference.get(path.extname(a)) ?? 99;
      const pb = preference.get(path.extname(b)) ?? 99;
      return pa - pb || a.localeCompare(b);
    });

  if (candidates.length === 0) return null;
  return path.join(outputDir, candidates[0]);
}

function hasGit() {
  const r = run('git', ['--version']);
  return r.status === 0;
}

function showDiff(expectedPath, generatedPath) {
  try {
    if (hasGit()) {
      const d = run('git', ['diff', '--no-index', expectedPath, generatedPath]);
      if (d.stdout) process.stdout.write(d.stdout);
      if (d.stderr) process.stderr.write(d.stderr);
      return;
    }
  } catch {}
  try {
    const d = run('diff', ['-u', expectedPath, generatedPath]);
    if (d.stdout) process.stdout.write(d.stdout);
    if (d.stderr) process.stderr.write(d.stderr);
    return;
  } catch {}
  // Last resort: print a small excerpt
  try {
    const exp = fs.readFileSync(expectedPath, 'utf8').split(/\r?\n/).slice(0, 40).join('\n');
    const gen = fs.readFileSync(generatedPath, 'utf8').split(/\r?\n/).slice(0, 40).join('\n');
    console.error('\n--- expected (first 40 lines)\n' + exp);
    console.error('\n--- generated (first 40 lines)\n' + gen);
  } catch {}
}

function packTarball(root) {
  // `npm pack --silent` prints the filename (usually one line)
  const res = runChecked(npmCmd(), ['pack', '--silent'], { cwd: root });
  const out = String(res.stdout || '')
    .trim()
    .split(/\r?\n/)
    .filter(Boolean);
  if (out.length === 0) throw new Error('npm pack produced no output');
  return out[out.length - 1].trim(); // tarball filename in root
}

function main() {
  const suiteStart = Date.now();
  let sequence = 0;
  const root = path.resolve(__dirname, '..');

  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'eyeling-smoke-'));
  const cleanup = () => rmrf(tmp);

  let tgzInRoot = null;

  try {
    info('Building tarball (npm pack)');
    let stepStart = Date.now();
    tgzInRoot = packTarball(root);
    const srcTgz = path.join(root, tgzInRoot);
    const dstTgz = path.join(tmp, tgzInRoot);

    fs.renameSync(srcTgz, dstTgz);
    pass(++sequence, `packed ${tgzInRoot}`, Date.now() - stepStart);

    info('Creating temp project + installing tarball');
    stepStart = Date.now();
    runChecked(npmCmd(), ['init', '-y'], { cwd: tmp, stdio: 'ignore' });
    runChecked(npmCmd(), ['install', `./${tgzInRoot}`, '--no-audit', '--no-fund'], { cwd: tmp, stdio: 'inherit' });
    pass(++sequence, 'created temp project and installed tarball', Date.now() - stepStart);

    info('API smoke test');
    // Run a tiny API check via node -e
    const apiCode = `
      const { reason } = require('eyeling');
      const input = \`
{ <http://example.org/s> <http://example.org/p> <http://example.org/o>. }
  => { <http://example.org/s> <http://example.org/q> <http://example.org/o>. }.

<http://example.org/s> <http://example.org/p> <http://example.org/o>.
\`;
      const out = reason({ proofComments: false }, input);
      const re = /<http:\\/\\/example\\.org\\/s>\\s+<http:\\/\\/example\\.org\\/q>\\s+<http:\\/\\/example\\.org\\/o>\\s*\\./;
      if (!re.test(out)) {
        console.error('Unexpected output:\\n' + out);
        process.exit(1);
      }
    `;
    stepStart = Date.now();
    runChecked(process.execPath, ['-e', apiCode], { cwd: tmp, stdio: 'inherit' });
    pass(++sequence, 'API works', Date.now() - stepStart);

    info('CLI smoke test');
    const bin = isWin()
      ? path.join(tmp, 'node_modules', '.bin', 'eyeling.cmd')
      : path.join(tmp, 'node_modules', '.bin', 'eyeling');
    stepStart = Date.now();
    runChecked(bin, ['-v'], { cwd: tmp, stdio: 'inherit' });
    pass(++sequence, 'CLI works', Date.now() - stepStart);

    info('Examples smoke test (installed package)');
    const pkgRoot = path.join(tmp, 'node_modules', 'eyeling');
    const examplesDir = path.join(pkgRoot, 'examples');
    const outputDir = path.join(examplesDir, 'output');
    const eyelingJsPath = path.join(pkgRoot, 'eyeling.js');

    if (!fs.existsSync(examplesDir)) throw new Error(`Missing examples directory in installed package: ${examplesDir}`);
    if (!fs.existsSync(outputDir))
      throw new Error(`Missing examples/output directory in installed package: ${outputDir}`);
    if (!fs.existsSync(eyelingJsPath)) throw new Error(`Missing eyeling.js in installed package: ${eyelingJsPath}`);

    // Keep this fast: package.test.js is a smoke test. The full matrix is covered by test/examples.test.js in-repo.
    const SMOKE_EXAMPLES = ['age.n3', 'basic-monadic.n3', 'family-cousins.n3', 'backward.n3', 'context-association.n3'];

    const tmpExamplesOut = fs.mkdtempSync(path.join(os.tmpdir(), 'eyeling-pkg-examples-'));
    stepStart = Date.now();
    try {
      for (const file of SMOKE_EXAMPLES) {
        const smokeStart = Date.now();
        const inputPath = path.join(examplesDir, file);
        const expectedPath = resolveExpectedPath(outputDir, file);

        if (!fs.existsSync(inputPath)) throw new Error(`Missing example in installed package: ${inputPath}`);
        if (!expectedPath || !fs.existsSync(expectedPath))
          throw new Error(`Missing golden output in installed package for ${file}`);

        const n3Text = fs.readFileSync(inputPath, 'utf8');
        const expectedRc = expectedExitCode(n3Text);

        const trigInput = resolveExampleTrigInput(examplesDir, file);
        const args = [eyelingJsPath, '-d'];
        if (trigInput) args.push('-r');
        args.push(file);
        if (trigInput) args.push(trigInput.rel);

        const r = cp.spawnSync(process.execPath, args, {
          cwd: examplesDir,
          stdio: ['ignore', 'pipe', 'pipe'],
          maxBuffer: 200 * 1024 * 1024,
          encoding: 'utf8',
        });

        const rc = r.status == null ? 1 : r.status;
        if (rc !== expectedRc) {
          const stderr = (r.stderr || '').trim();
          throw new Error(
            `Example ${file}: exit ${rc}, expected ${expectedRc}${
              stderr
                ? `
${stderr}`
                : ''
            }`,
          );
        }

        // Normalize newlines so this is stable across platforms.
        const got = normalizeNewlines(r.stdout || '');
        const exp = normalizeNewlines(fs.readFileSync(expectedPath, 'utf8'));
        const compare = path.extname(expectedPath) === '.md' ? normalizeMarkdownForCompare : normalizeTextForCompare;

        if (compare(got) !== compare(exp)) {
          const genPath = path.join(tmpExamplesOut, path.basename(expectedPath));
          fs.writeFileSync(genPath, got, 'utf8');
          console.error(`
Output differs for ${file}:`);
          showDiff(expectedPath, genPath);
          throw new Error(`Example ${file}: output differs from golden`);
        }

        pass(++sequence, `Example smoke: ${file}`, Date.now() - smokeStart);
      }
    } finally {
      rmrf(tmpExamplesOut);
    }
    pass(++sequence, 'Installed examples smoke test passed', Date.now() - stepStart);

    const suiteMs = Date.now() - suiteStart;
    console.log('');
    info(`Packaged install smoke test passed (${suiteMs} ms, ${(suiteMs / 1000).toFixed(2)} s)`);
    process.exit(0);
  } catch (e) {
    console.log('');
    failResult(++sequence, 'packaged install smoke test failed', Date.now() - suiteStart);
    detail(e && e.stack ? e.stack : String(e));
    process.exit(1);
  } finally {
    // If rename failed and the tarball still exists in root, try to delete it
    if (tgzInRoot) {
      const maybe = path.join(root, tgzInRoot);
      if (fs.existsSync(maybe)) {
        try {
          fs.unlinkSync(maybe);
        } catch {}
      }
    }
    cleanup();
  }
}

main();
