# pn-junction-tunneling  

## Source files  

- [N3 rules](../pn-junction-tunneling.n3)  

## Answer  
In this toy PN-junction tunneling model, heavy doping narrows the depletion region enough for a tunneling window that rises to a peak and then falls, producing a negative-differential region.  
case                          : pn-junction-tunneling  
peak bias                     : 2  
peak current proxy            : 4  
negative differential region  : yes  

## Reason Why  
We model tunneling current as an exact overlap count between filled N-side states and empty P-side states while forward bias shifts the bands. Heavy doping is represented by a much narrower depletion region.  
ordinary depletion width (nm) : 8  
tunnel depletion width (nm)   : 1  
filled N-side states          : [1, 2, 3, 4]  
empty P-side states at 0 bias : [3, 4, 5, 6]  
bias -> overlap current proxy : 0->2, 1->3, 2->4, 3->3, 4->2, 5->1, 6->0  
peak point                    : 2 -> 4  
high-bias point               : 6 -> 0  

## Check  
heavily doped barrier is narrower : yes  
peak occurs before overlap closes : yes  
negative differential region present : yes  
high-bias overlap closes           : yes  
peak equals full four-state overlap: yes  
