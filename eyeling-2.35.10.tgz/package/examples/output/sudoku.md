# sudoku  

## Source files  

- [N3 rules](../sudoku.n3)  

## Answer  
The puzzle is solved, and the completed grid is the unique valid Sudoku solution.  
case              : sudoku  
default puzzle    : classic  

Puzzle  
1 . . | . . 7 | . 9 .  
. 3 . | . 2 . | . . 8  
. . 9 | 6 . . | 5 . .  

. . 5 | 3 . . | 9 . .  
. 1 . | . 8 . | . . 2  
6 . . | . . 4 | . . .  

3 . . | . . . | . 1 .  
. 4 . | . . . | . . 7  
. . 7 | . . . | 3 . .  

Completed grid  
1 6 2 | 8 5 7 | 4 9 3  
5 3 4 | 1 2 9 | 6 7 8  
7 8 9 | 6 4 3 | 5 2 1  

4 7 5 | 3 1 2 | 9 8 6  
9 1 3 | 5 8 6 | 7 4 2  
6 2 8 | 7 9 4 | 1 3 5  

3 5 6 | 4 7 8 | 2 1 9  
2 4 1 | 9 3 5 | 8 6 7  
8 9 7 | 2 6 1 | 3 5 4  

## Reason Why  
The solver starts from 23 clues and fills the remaining 58 cells by combining constraint propagation with depth-first search. At each step it chooses the empty cell with the fewest legal digits, places forced singles immediately, and only guesses when more than one candidate remains. Across the search it made 213 forced placements and tried 22 guesses, visited 23 search nodes overall, and backtracked 12 times before reaching the completed grid. The solver also confirmed that the solution is unique. Early steps: r2c3=4: guess, r5c3=3: forced, r2c1=5: guess, r2c4=1: guess, r2c6=9: forced, r2c7=6: guess, r2c8=7: forced, r1c7=4: guess, … and 50 more placements  

## Check  
C1 OK - every given clue is preserved in the final grid.  
C2 OK - the final grid contains only digits 1 through 9, with no blanks left.  
C3 OK - each row contains every digit exactly once.  
C4 OK - each column contains every digit exactly once.  
C5 OK - each 3×3 box contains every digit exactly once.  
C6 OK - replaying the recorded placements from the original puzzle remains legal at every step.  
C7 OK - the search statistics and the successful proof path are internally consistent.  
C8 OK - a second search found no alternative solution, so the solution is unique.  
