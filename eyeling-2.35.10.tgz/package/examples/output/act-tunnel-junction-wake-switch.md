# act-tunnel-junction-wake-switch  

## Source files  

- [N3 rules](../act-tunnel-junction-wake-switch.n3)  

ACT tunnel-junction wake switch  

## Answer  
YES for the tunnel junction.  
NO for the conventional low-bias PN junction in the same wake-switch regime.  

## Reason Why  
The tunnel junction is modeled as a heavily doped narrow PN junction with overlapping states, so quantum barrier transfer is possible. That makes sub-threshold current possible in the low-forward-bias regime, which in turn makes ultra-low-bias switching possible for the wake circuit. Because the device is also scanned through a peak-to-valley window, a negative differential response is possible as well. By contrast, the conventional junction lacks the structural conditions for the same transfer mode, so it cannot deliver the same low-bias switching task in this case.  

## Check  
C1  OK - the tunnel junction can support quantum barrier transfer  
C2  OK - the tunnel junction is classified as tunneling-dominant  
C3  OK - the tunnel junction can deliver sub-threshold current  
C4  OK - the tunnel junction can show negative differential response  
C5  OK - the tunnel junction can perform ultra-low-bias switching  
C6  OK - the tunnel junction can serve the leak-alarm wake circuit  
C7  OK - the conventional junction cannot support the same quantum barrier transfer  
C8  OK - the conventional junction cannot deliver sub-threshold current in this regime  
C9  OK - the conventional junction cannot show the tunnel-style negative differential response  
C10 OK - the conventional junction cannot perform ultra-low-bias switching here  
C11 OK - the conventional junction cannot serve the leak-alarm wake circuit in this case  
