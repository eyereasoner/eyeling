# deep-taxonomy-1000  

## Source files  

- [N3 rules](../deep-taxonomy-1000.n3)  

Deep Taxonomy - deep classification benchmark  

## Answer  
The test succeeds: starting from one individual classified as N0, the rules eventually classify it as N1000 and then as A2.  

## Reason Why  
Each rule moves the same individual one level deeper in the taxonomy and also adds two side labels. Because that chain continues all the way from N0 to N1000, the final rule deriving A2 fires, and that in turn makes the test true.  

## Check  
C1 OK - the starting classification N0 is present.  
C2 OK - the first expansion produced N1 together with side labels I1 and J1.  
C3 OK - the chain reaches the midpoint N500 and still carries both side-label branches.  
C4 OK - the final taxonomy step from N999 to N1000 was completed.  
C5 OK - once N1000 is reached, the terminal class A2 is derived.  
C6 OK - the success flag is raised only after the terminal class A2 is present.  
