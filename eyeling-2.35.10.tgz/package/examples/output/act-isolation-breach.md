# act-isolation-breach  

## Source files  

- [N3 rules](../act-isolation-breach.n3)  

ACT isolation-breach token — broad constructor-theory coverage case  

## Answer  
YES for the classical isolation-breach token.  
NO for universal cloning and unrestricted fan-out of the quantum provenance seal.  

## Reason Why  
The isolation-breach token is treated as an abstract information variable carried by unlike classical media: a door beacon, a containment PLC, a nurse pager, and an incident board. Because those substrates are information media for the same variable, the token can be prepared, permuted, reversed, cloned locally, copied across media, measured into an output record, and composed into serial and parallel task networks. By contrast, the specimen seal is treated as a superinformation medium, so cloning all of its states is impossible and unrestricted parallel fan-out is blocked.  

## Check  
C1  OK - the door beacon is an information medium  
C2  OK - the containment PLC is an information medium  
C3  OK - the nurse pager is an information medium  
C4  OK - the incident board is an information medium  
C5  OK - the door beacon distinguishes the breach bit  
C6  OK - the breach state can be prepared on the nurse pager  
C7  OK - permutation from safe to breach is possible on the door beacon  
C8  OK - the door beacon supports reversible permutation  
C9  OK - local cloning of the breach bit is possible on the containment PLC  
C10 OK - the breach bit can be copied from door beacon to containment PLC  
C11 OK - the breach bit can be copied from containment PLC to nurse pager  
C12 OK - the breach bit can be measured from nurse pager into the incident board  
C13 OK - a serial network from door beacon via containment PLC to incident board is possible  
C14 OK - a parallel network from containment PLC to nurse pager and incident board is possible  
C15 OK - cloning all states of the specimen seal is an impossible task  
C16 OK - the specimen seal cannot be universally cloned  
C17 OK - the specimen seal cannot support unrestricted parallel fan-out  
