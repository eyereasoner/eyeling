# delfour  

## Source files  

- [N3 rules](../delfour.n3)  

## Answer  
The scanner is allowed to use a neutral shopping insight and recommends Low-Sugar Tea Biscuits instead of Classic Tea Biscuits.  
case                 : delfour  
decision             : Allowed  
scanned product      : Classic Tea Biscuits  
suggested alternative: Low-Sugar Tea Biscuits  

## Reason Why  
The phone desensitizes a diabetes-related household condition into a scoped low-sugar need, wraps it in an expiring Insight + Policy envelope, signs it, and the scanner consumes that envelope for shopping assistance.  
metric               : sugar_g_per_serving  
threshold            : 10.0  
scope                : self-scanner @ pick_up_scanner  
retailer             : Delfour  
signature alg        : HMAC-SHA256  
banner headline      : Track sugar per serving while you scan  
expires at           : 2025-10-05T22:33:48.907185+00:00  
reason.txt           : Household requires low-sugar guidance (diabetes in POD). A neutral Insight is scoped to device 'self-scanner', event 'pick_up_scanner', retailer 'Delfour', and expires soon; the policy confines use to shopping assistance.  
audit entries        : 1  
bus files written    : 6  

## Check  
signature verifies              : yes  
payload hash matches            : yes  
minimization strips sensitive terms: yes  
scope complete                  : yes  
authorization allowed           : yes  
high-sugar banner               : yes  
alternative lowers sugar        : yes  
duty timing consistent          : yes  
marketing prohibited            : yes  
