# auroracare  

## Source files  

- [N3 rules](../auroracare.n3)  

AuroraCare — Purpose-based Medical Data Exchange  

## A – Primary care visit  
Clinician in the patient's care team accessing the patient summary for primary care management.  

## Answer  
PERMIT  

## Reason Why  
Permitted: clinician in the patient's care team, and the primary-care policy matched.  

## Check  
C1 SKIPPED - not a prohibited purpose  
C2 OK - clinician  
C3 OK - care-team linked  
C4 SKIPPED  
C5 OK - operator=isAnyOf, allowed=["https://example.org/health#PATIENT_SUMMARY","https://example.org/health#LAB_RESULTS"], requested=["https://example.org/health#PATIENT_SUMMARY"]  
C6 SKIPPED - no prohibition matched  
C7 OK - trace shows matching permission  
C8 SKIPPED - no matched policy or no duties  
C9 SKIPPED - policy has no environment constraint  
C10 INFO - matched policy: urn:policy:primary-care-001  

## B – Quality improvement (in scope)  
QI analyst using lab results + summary in a secure environment.  

## Answer  
PERMIT  

## Reason Why  
Permitted: ODRL/DPV policy matched for secondary use.  

## Check  
C1 SKIPPED - not a prohibited purpose  
C2 SKIPPED  
C3 SKIPPED  
C4 OK - opt-in present and policy matched  
C5 OK - operator=isAllOf, allowed=["https://example.org/health#LAB_RESULTS","https://example.org/health#PATIENT_SUMMARY"], requested=["https://example.org/health#LAB_RESULTS","https://example.org/health#PATIENT_SUMMARY"]  
C6 SKIPPED - no prohibition matched  
C7 OK - trace shows matching permission  
C8 INFO - duties attached: duty:https://w3id.org/dpv/legal/eu/ehds#requireConsent, duty:https://w3id.org/dpv/legal/eu/ehds#noExfiltration  
C9 OK - operator=eq, allowed="secure_env", requested="secure_env"  
C10 INFO - matched policy: urn:policy:qi-2025-aurora  

## C – Quality improvement (out of scope)  
QI analyst with only lab results; policy expects labs + summary.  

## Answer  
DENY  

## Reason Why  
Denied: no policy matched (purpose, environment, TOMs, or categories out of scope).  

## Check  
C1 SKIPPED - not a prohibited purpose  
C2 SKIPPED  
C3 SKIPPED  
C4 OK - denied because opt-in missing or no policy match  
C5 SKIPPED  
C6 SKIPPED - no prohibition matched  
C7 SKIPPED  
C8 SKIPPED - no matched policy or no duties  
C9 SKIPPED  
C10 SKIPPED - no matched policy  

## D – Insurance management  
Insurance bot attempting to use health data for insurance management (prohibited purpose).  

## Answer  
DENY  

## Reason Why  
Denied: the requested purpose (insurance management) is prohibited by policy.  

## Check  
C1 OK - denied prohibited purpose  
C2 SKIPPED  
C3 SKIPPED  
C4 SKIPPED  
C5 SKIPPED  
C6 OK - denied due to prohibition  
C7 SKIPPED  
C8 SKIPPED - no matched policy or no duties  
C9 SKIPPED  
C10 SKIPPED - no matched policy  

## E – GP checks labs  
GP for the same patient checking lab results via the API gateway.  

## Answer  
PERMIT  

## Reason Why  
Permitted: clinician in the patient's care team, and the primary-care policy matched.  

## Check  
C1 SKIPPED - not a prohibited purpose  
C2 OK - clinician  
C3 OK - care-team linked  
C4 SKIPPED  
C5 OK - operator=isAnyOf, allowed=["https://example.org/health#PATIENT_SUMMARY","https://example.org/health#LAB_RESULTS"], requested=["https://example.org/health#LAB_RESULTS"]  
C6 SKIPPED - no prohibition matched  
C7 OK - trace shows matching permission  
C8 SKIPPED - no matched policy or no duties  
C9 SKIPPED - policy has no environment constraint  
C10 INFO - matched policy: urn:policy:primary-care-001  

## F – Research on anonymised dataset  
Researcher using anonymised labs + summary in a secure environment, with opt-in.  

## Answer  
PERMIT  

## Reason Why  
Permitted: subject opted in and an ODRL/DPV policy matched (anonymised dataset in secure environment).  

## Check  
C1 SKIPPED - not a prohibited purpose  
C2 SKIPPED  
C3 SKIPPED  
C4 OK - opt-in present and policy matched  
C5 OK - operator=isAnyOf, allowed=["https://example.org/health#LAB_RESULTS","https://example.org/health#PATIENT_SUMMARY","https://example.org/health#IMAGING_REPORT"], requested=["https://example.org/health#PATIENT_SUMMARY","https://example.org/health#LAB_RESULTS"]  
C6 SKIPPED - no prohibition matched  
C7 OK - trace shows matching permission  
C8 INFO - duties attached: duty:https://w3id.org/dpv/legal/eu/ehds#annualOutcomeReport, duty:https://w3id.org/dpv/legal/eu/ehds#noReidentification, duty:https://w3id.org/dpv/legal/eu/ehds#noExfiltration  
C9 OK - operator=eq, allowed="secure_env", requested="secure_env"  
C10 INFO - matched policy: urn:policy:research-aurora-diabetes  

## G – AI training (opt-out)  
Data user wants to train AI, but the subject opted out of AI training.  

## Answer  
DENY  

## Reason Why  
Denied: you opted out of your data being used to train AI systems.  

## Check  
C1 SKIPPED - not a prohibited purpose  
C2 SKIPPED  
C3 SKIPPED  
C4 OK - denied because opt-in missing or no policy match  
C5 SKIPPED  
C6 SKIPPED - no prohibition matched  
C7 SKIPPED  
C8 SKIPPED - no matched policy or no duties  
C9 SKIPPED  
C10 SKIPPED - no matched policy  
