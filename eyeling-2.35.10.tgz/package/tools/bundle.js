#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const ENTRY = path.join(ROOT, 'lib', 'entry.js');
const NODE_OUT = path.join(ROOT, 'eyeling.js');
const BROWSER_DIR = path.join(ROOT, 'dist', 'browser');
const BROWSER_BUNDLE_OUT = path.join(BROWSER_DIR, 'eyeling.browser.js');
const BROWSER_ENTRY_OUT = path.join(BROWSER_DIR, 'index.mjs');

function normalizeRel(p) {
  return path.relative(ROOT, p).split(path.sep).join('/');
}

function isInternalRequest(req) {
  return typeof req === 'string' && (req.startsWith('./') || req.startsWith('../'));
}

function resolveInternal(fromFile, req) {
  const baseDir = path.dirname(fromFile);
  let abs = path.resolve(baseDir, req);

  if (!path.extname(abs)) abs += '.js';
  if (fs.existsSync(abs) && fs.statSync(abs).isDirectory()) {
    abs = path.join(abs, 'index.js');
  }

  return abs;
}

function parseRequires(src) {
  const re = /require\(\s*['"]([^'"]+)['"]\s*\)/g;
  const out = [];
  let m;
  while ((m = re.exec(src))) out.push(m[1]);
  return out;
}

/** @type {Map<string,string>} */
const modules = new Map();

function addModule(absFile) {
  const rel = normalizeRel(absFile);
  if (modules.has(rel)) return;

  const src = fs.readFileSync(absFile, 'utf8');
  modules.set(rel, src);

  for (const req of parseRequires(src)) {
    if (!isInternalRequest(req)) continue;
    if (req.endsWith('.json')) continue;

    const depAbs = resolveInternal(absFile, req);
    if (!normalizeRel(depAbs) || !path.resolve(depAbs).startsWith(ROOT)) continue;
    if (!fs.existsSync(depAbs)) continue;
    addModule(depAbs);
  }
}

function buildBundleSource({ autoRunMain }) {
  addModule(ENTRY);
  const keys = Array.from(modules.keys()).sort();

  const out = [];
  out.push("'use strict';");
  out.push('');
  out.push('(function(){');
  out.push('  const __outerRequire = (typeof require === "function") ? require : null;');
  out.push('  const __outerModule = (typeof module !== "undefined") ? module : null;');
  out.push('  const __outerSelf = (typeof self !== "undefined") ? self : null;');
  out.push('  const __modules = Object.create(null);');
  out.push('  const __cache = Object.create(null);');
  out.push('');
  out.push('  // ---- bundled modules ----');
  for (const k of keys) {
    out.push(`  __modules[${JSON.stringify(k)}] = function(require, module, exports){`);
    out.push(modules.get(k).replace(/\r\n/g, '\n'));
    out.push('  };');
  }

  out.push('');
  out.push('  function __normPath(p){');
  out.push('    const segs = [];');
  out.push('    for (const part of p.split("/")) {');
  out.push('      if (!part || part === ".") continue;');
  out.push('      if (part === "..") segs.pop();');
  out.push('      else segs.push(part);');
  out.push('    }');
  out.push('    return segs.join("/");');
  out.push('  }');

  out.push('  function __resolve(fromId, req){');
  out.push('    if (!(req && (req.startsWith("./") || req.startsWith("../")))) return req;');
  out.push('    const base = fromId.split("/").slice(0, -1).join("/");');
  out.push('    let p = base ? (base + "/" + req) : req;');
  out.push('    p = __normPath(p);');
  out.push('    if (!p.endsWith(".js") && !p.endsWith(".json")) p += ".js";');
  out.push('    return p;');
  out.push('  }');

  out.push('  function __makeRequire(fromId){');
  out.push('    function r(req){');
  out.push('      if (!(req && (req.startsWith("./") || req.startsWith("../")))) {');
  out.push('        if (__outerRequire) return __outerRequire(req);');
  out.push('        throw new Error("Cannot require external module: " + req);');
  out.push('      }');
  out.push('      const id = __resolve(fromId, req);');
  out.push('      if (!__modules[id]) {');
  out.push('        if (__outerRequire) return __outerRequire(req);');
  out.push('        throw new Error("Cannot find bundled module: " + id);');
  out.push('      }');
  out.push('      if (__cache[id]) return __cache[id].exports;');
  out.push('      const m = { exports: {} };');
  out.push('      __cache[id] = m;');
  out.push('      __modules[id](__makeRequire(id), m, m.exports);');
  out.push('      return m.exports;');
  out.push('    }');
  out.push('    r.main = (__outerRequire && __outerRequire.main) ? __outerRequire.main : null;');
  out.push('    return r;');
  out.push('  }');

  out.push('');
  out.push('  function __loadEntry(){');
  out.push(`    const id = ${JSON.stringify(normalizeRel(ENTRY))};`);
  out.push('    if (!__modules[id]) throw new Error("Missing entry module: " + id);');
  out.push('    if (__cache[id]) return __cache[id].exports;');
  out.push('    const m = { exports: {} };');
  out.push('    __cache[id] = m;');
  out.push('    __modules[id](__makeRequire(id), m, m.exports);');
  out.push('    return m.exports;');
  out.push('  }');

  out.push('  const __entry = __loadEntry();');
  out.push('  const __api = __entry;');
  out.push('');
  out.push(
    '  try { if (__outerModule && __outerModule.exports) __outerModule.exports = __api; } catch (ignoredError) {}',
  );
  out.push('  try { if (__outerSelf) __outerSelf.eyeling = __api; } catch (ignoredError) {}');
  out.push('');
  out.push('  // ---- playground.html compatibility ----');
  out.push('  // The original monolithic eyeling.js exposed internal functions/flags as globals.');
  out.push('  // playground.html still uses these via importScripts(...) inside a web worker.');
  out.push('  try {');
  out.push('    if (__outerSelf && __entry) {');
  out.push('      if (typeof __entry.lex === "function") __outerSelf.lex = __entry.lex;');
  out.push('      if (typeof __entry.Parser === "function") __outerSelf.Parser = __entry.Parser;');
  out.push('      if (typeof __entry.forwardChain === "function") __outerSelf.forwardChain = __entry.forwardChain;');
  out.push(
    '      if (typeof __entry.materializeRdfLists === "function") __outerSelf.materializeRdfLists = __entry.materializeRdfLists;',
  );
  out.push(
    '      if (typeof __entry.isGroundTriple === "function") __outerSelf.isGroundTriple = __entry.isGroundTriple;',
  );
  out.push(
    '      if (typeof __entry.printExplanation === "function") __outerSelf.printExplanation = __entry.printExplanation;',
  );
  out.push(
    '      if (typeof __entry.renderProofDocument === "function") __outerSelf.renderProofDocument = __entry.renderProofDocument;',
  );
  out.push('      if (typeof __entry.tripleToN3 === "function") __outerSelf.tripleToN3 = __entry.tripleToN3;');
  out.push(
    '      if (typeof __entry.collectOutputStringsFromFacts === "function") __outerSelf.collectOutputStringsFromFacts = __entry.collectOutputStringsFromFacts;',
  );
  out.push(
    '      if (typeof __entry.prettyPrintQueryTriples === "function") __outerSelf.prettyPrintQueryTriples = __entry.prettyPrintQueryTriples;',
  );
  out.push('');
  out.push('      const def = (name, getFn, setFn) => {');
  out.push('        try {');
  out.push('          if (typeof Object.defineProperty === "function") {');
  out.push('            Object.defineProperty(__outerSelf, name, {');
  out.push('              configurable: true,');
  out.push('              get: (typeof getFn === "function") ? getFn : undefined,');
  out.push('              set: (typeof setFn === "function") ? setFn : undefined,');
  out.push('            });');
  out.push('          } else {');
  out.push('            if (typeof getFn === "function") __outerSelf[name] = getFn();');
  out.push('          }');
  out.push('        } catch (ignoredError) {}');
  out.push('      };');
  out.push('');
  out.push('      def("enforceHttpsEnabled", __entry.getEnforceHttpsEnabled, __entry.setEnforceHttpsEnabled);');
  out.push('      def("proofCommentsEnabled", __entry.getProofCommentsEnabled, __entry.setProofCommentsEnabled);');
  out.push('      def("__tracePrefixes", __entry.getTracePrefixes, __entry.setTracePrefixes);');
  out.push('    }');
  out.push('  } catch (ignoredError) {}');
  out.push('');

  if (autoRunMain) {
    out.push('  try {');
    out.push(
      '    if (__outerModule && __outerRequire && __outerRequire.main === __outerModule && typeof __entry.main === "function") {',
    );
    out.push('      const __mainResult = __entry.main();');
    out.push('      if (__mainResult && typeof __mainResult.then === "function") {');
    out.push('        __mainResult.catch((e) => {');
    out.push('          try { if (typeof console !== "undefined" && console.error) console.error(e && e.stack ? e.stack : e && e.message ? e.message : String(e)); } catch (ignoredError) {}');
    out.push('          try { if (typeof process !== "undefined" && process.exit) process.exit(1); } catch (ignoredError) {}');
    out.push('        });');
    out.push('      }');
    out.push('    }');
    out.push('  } catch (ignoredError) {}');
  }

  out.push('})();');

  return { source: out.join('\n') + '\n', moduleCount: keys.length };
}

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function writeFile(file, contents, mode) {
  ensureDir(path.dirname(file));
  fs.writeFileSync(file, contents, { encoding: 'utf8' });
  if (mode != null) {
    try {
      fs.chmodSync(file, mode);
    } catch (_) {}
  }
}

function buildBrowserEntry() {
  return `import './eyeling.browser.js';

function getBrowserApi() {
  const api = typeof globalThis !== 'undefined' ? globalThis.eyeling : undefined;
  if (!api) {
    throw new Error(
      'Eyeling browser bundle is not initialized. Import "eyeling/browser" only in a browser or worker runtime.',
    );
  }
  return api;
}

export const INFERENCE_FUSE_EXIT_CODE = 65;

export function runAsync(input, opts) {
  return getBrowserApi().runAsync(input, opts);
}

export function reasonStream(input, opts) {
  return getBrowserApi().reasonStream(input, opts);
}

export function reasonRdfJs(input, opts) {
  return getBrowserApi().reasonRdfJs(input, opts);
}

export function parseN3Text(text, opts) {
  return getBrowserApi().parseN3Text(text, opts);
}

export function createFactStore(options) {
  return getBrowserApi().createFactStore(options);
}

export function registerBuiltin(iri, handler) {
  return getBrowserApi().registerBuiltin(iri, handler);
}

export function unregisterBuiltin(iri) {
  return getBrowserApi().unregisterBuiltin(iri);
}

export function registerBuiltinModule(mod, origin) {
  return getBrowserApi().registerBuiltinModule(mod, origin);
}

export function listBuiltinIris() {
  return getBrowserApi().listBuiltinIris();
}

export function collectOutputStringsFromFacts(facts, prefixes) {
  return getBrowserApi().collectOutputStringsFromFacts(facts, prefixes);
}

export function prettyPrintQueryTriples(triples, prefixes) {
  return getBrowserApi().prettyPrintQueryTriples(triples, prefixes);
}

export const rdfjs = new Proxy(Object.create(null), {
  get(_target, prop) {
    return Reflect.get(getBrowserApi().rdfjs, prop);
  },
  set(_target, prop, value) {
    return Reflect.set(getBrowserApi().rdfjs, prop, value);
  },
  has(_target, prop) {
    return prop in getBrowserApi().rdfjs;
  },
  ownKeys() {
    return Reflect.ownKeys(getBrowserApi().rdfjs);
  },
  getOwnPropertyDescriptor(_target, prop) {
    return Object.getOwnPropertyDescriptor(getBrowserApi().rdfjs, prop);
  },
});

const eyeling = {
  get version() {
    return getBrowserApi().version;
  },
  INFERENCE_FUSE_EXIT_CODE,
  runAsync,
  reasonStream,
  reasonRdfJs,
  parseN3Text,
  rdfjs,
  createFactStore,
  registerBuiltin,
  unregisterBuiltin,
  registerBuiltinModule,
  listBuiltinIris,
  collectOutputStringsFromFacts,
  prettyPrintQueryTriples,
};

export default eyeling;
`;
}

function main() {
  const nodeBundle = buildBundleSource({ autoRunMain: true });
  const browserBundle = buildBundleSource({ autoRunMain: false });

  writeFile(NODE_OUT, nodeBundle.source);
  writeFile(BROWSER_BUNDLE_OUT, browserBundle.source);
  writeFile(BROWSER_ENTRY_OUT, buildBrowserEntry());

  console.log(`Wrote ${path.relative(process.cwd(), NODE_OUT)} with ${nodeBundle.moduleCount} modules`);
  console.log(`Wrote ${path.relative(process.cwd(), BROWSER_BUNDLE_OUT)} with ${browserBundle.moduleCount} modules`);
  console.log(`Wrote ${path.relative(process.cwd(), BROWSER_ENTRY_OUT)}`);
}

main();
